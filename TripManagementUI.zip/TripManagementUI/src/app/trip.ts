import { Time } from "@angular/common"

export class Trip {
    tripId!: string
    creatorUserId !: Number
    vehicleId !: string
    rideDate !: Date
    rideTime !: Time
    rideStatus!:string
  
    noOfSeat!: number
    seatsFilled !:number
    fromLoc!: string
    toLoc!: string 

}
