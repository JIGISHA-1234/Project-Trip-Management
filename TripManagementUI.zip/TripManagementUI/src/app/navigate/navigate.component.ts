import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-navigate',
  templateUrl: './navigate.component.html',
  styleUrls: ['./navigate.component.css']
})
export class NavigateComponent {
  authenticated:boolean=false;
  constructor(private router:Router, public authenticatedUsersService:UserService) { 
    if(this.authenticatedUsersService.isUserLoggedIn()){
      // this.router.navigate(['addTrip']);
      console.log("reload");
    }
    
  }

  ngOnInit(): void {
  }
  logout(){
    this.authenticatedUsersService.logOut();
    this.router.navigate(['login']);
  }

}
