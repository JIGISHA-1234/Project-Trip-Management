export class Responcebooking {
    bookingId!: number
    noSeats!: number
    seekerId!: string
    bookingStatus!: string
    trip!:string
}
