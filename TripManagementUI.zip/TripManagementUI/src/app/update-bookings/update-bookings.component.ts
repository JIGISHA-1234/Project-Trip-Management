import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Bookings } from '../bookings';
import { BookingsServiceService } from '../bookings-service.service';

@Component({
  selector: 'app-update-bookings',
  templateUrl: './update-bookings.component.html',
  styleUrls: ['./update-bookings.component.css']
})
export class UpdateBookingsComponent {
 
  allbookings : any;
  

  constructor( private bookingsService:BookingsServiceService , private router: Router){
    this.bookingsService.getAllBooking().subscribe(data=>{
      this.allbookings=data;})
}



update(bookingId:number,bookings:Bookings){
  this.bookingsService.updateTrips(bookingId,bookings).subscribe(data=>console.log("update"),error=>
  {
    console.log(error)
    alert('Data not updated');
    
  }
  );
  // this.trip=new Trip();
  this.goToListOfBookingsPage()

  
}
goToListOfBookingsPage(){
               
  this.router.navigate(['/bookings'])
}



}
