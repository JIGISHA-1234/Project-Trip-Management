import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAllTripsComponent } from './get-all-trips.component';

describe('GetAllTripsComponent', () => {
  let component: GetAllTripsComponent;
  let fixture: ComponentFixture<GetAllTripsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetAllTripsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetAllTripsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
