import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Trip } from '../trip';
import { TripServiceService } from '../trip-service.service';

@Component({
  selector: 'app-get-all-trips',
  templateUrl: './get-all-trips.component.html',
  styleUrls: ['./get-all-trips.component.css']
})
export class GetAllTripsComponent implements OnInit{
 
  trips: Trip[]=[];
  


  constructor( private tripService:TripServiceService , private router: Router){
    this.getAllTrips();
  }


  ngOnInit(): void {
    this.getAllTrips();
    
  }
    getAllTrips(){
      this.tripService.getAllTrip().subscribe(data=>{
        this.trips=data;
      },
      error =>{
        alert("Something went wrong");
        window.location.reload();
      }
      )

    }
  


    

}
