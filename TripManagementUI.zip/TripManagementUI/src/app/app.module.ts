import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GetAllTripsComponent } from './get-all-trips/get-all-trips.component';
import { AddTripComponent } from './add-trip/add-trip.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AddBookingsComponent } from './add-bookings/add-bookings.component';
import { GetBookingsComponent } from './get-bookings/get-bookings.component';
import { UpdateTripComponent } from './update-trip/update-trip.component';
import { UpdateBookingsComponent } from './update-bookings/update-bookings.component';
import { LoginComponent } from './login/login.component';
import { NavigateComponent } from './navigate/navigate.component';


@NgModule({
  declarations: [
    AppComponent,
    GetAllTripsComponent,
    AddTripComponent,
    AddBookingsComponent,
    GetBookingsComponent,
    UpdateTripComponent,
    UpdateBookingsComponent,
    LoginComponent,
    NavigateComponent,

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
