import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Bookings } from '../bookings';
import { BookingsServiceService } from '../bookings-service.service';

@Component({
  selector: 'app-add-bookings',
  templateUrl: './add-bookings.component.html',
  styleUrls: ['./add-bookings.component.css']
})
export class AddBookingsComponent implements OnInit {

  bookings: Bookings = new Bookings();
  submitted=false;
  errorforfe: String  = "Error";
  ifError = false;
  isPositive=true;
  isIntegerSeat=true

  errorMessage !: '';



  constructor(private bookingsService: BookingsServiceService, private router: Router) {

  }
  ngOnInit(): void {


  }



  addBookingsData() {
    console.log(this.bookings);

    this.bookingsService.addBookings(this.bookings).subscribe(response => {


      console.log(response);
      this.submitted=true;
      this.ifError = false;
      // this.goToListOfBookingsPage()

    },error=>{
      console.log(error)
      this.errorforfe = error.error;

      this.ifError=true;
      this.errorMessage=error;
      // alert(error)
      // alert("Invalid Input");
      
      console.log(this.errorforfe)

    }
      
    
    )
    console.log(this.errorforfe);
  }
  onSubmit() {
   
    this.addBookingsData()
  }

  // goToListOfBookingsPage() {

  //   this.router.navigate(['/bookings'])
  // }

  givePositiveValue(){
    let value=this.bookings.noSeats;
    if(value<=0)
    {
      this.isPositive=false;
    }
    else{
      this.isPositive=true;
    }
  }
  
  giveIntegerSeat(){
    let value:Number=this.bookings.noSeats;
    
    
    const numberString = value.toString();
    const isFloat = /\d+\.\d+/.test(
        numberString
    );

    if(isFloat || Number.isInteger(value))
    {
      this.isIntegerSeat=false;
    }
    else{
      this.isIntegerSeat=true;
    }
   
  }

  form={
    noSeats:'',
    seekerId:'',
    tripId:'',

  
  }
}
