import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Trip } from '../trip';
import { TripServiceService } from '../trip-service.service';

@Component({
  selector: 'app-update-trip',
  templateUrl: './update-trip.component.html',
  styleUrls: ['./update-trip.component.css']
})
export class UpdateTripComponent {
  trips: Trip[]=[];
  // tripService: any;

  constructor( private tripService:TripServiceService , private router: Router){
        this.tripService.getAllTrip().subscribe((data: Trip[])=>{
          this.trips=data;
        })
  }
  

  // ngOnInit(): void {
  //   // this.getAllTrips();
    
  // }
    // getAllTrips(){
    //   this.tripService.getAllTrip().subscribe((data: Trip[])=>{
    //     this.trips=data;
    //   })

    // }

    updateTrip(tripId:string,trip:Trip){
      this.tripService.updateTrips(tripId,trip).subscribe(data=>console.log(data),error=>{
        console.log(error);
        alert("Unable to update the trip")
      });
      // this.trip=new Trip();
      this.goToListOfTripPage();
    }
  
    goToListOfTripPage(){
               
      this.router.navigate(['/trips'])
    }
    

}
