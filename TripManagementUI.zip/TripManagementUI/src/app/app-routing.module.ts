import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddBookingsComponent } from './add-bookings/add-bookings.component';
import { AddTripComponent } from './add-trip/add-trip.component';
import { AuthGuardService } from './auth-guard.service';
import { GetAllTripsComponent } from './get-all-trips/get-all-trips.component';
import { GetBookingsComponent } from './get-bookings/get-bookings.component';
import { LoginComponent } from './login/login.component';
import { UpdateBookingsComponent } from './update-bookings/update-bookings.component';
import { UpdateTripComponent } from './update-trip/update-trip.component';

// import { UpdateTripComponent } from './update-trip/update-trip.component';

 
const routes: Routes = [
  {path:"login", component:LoginComponent},
{path:'trips',component:GetAllTripsComponent},
{path:'addTrip', component:AddTripComponent ,canActivate:[AuthGuardService]},
// {path:'update-trip/:tripId', component:UpdateTripComponent },
// {path:'',component:GetAllTripsComponent}

{path:'addBookings', component:AddBookingsComponent,canActivate:[AuthGuardService] },
{path:'bookings', component:GetBookingsComponent },
{path:'updateTrip', component:UpdateTripComponent,canActivate:[AuthGuardService] },
{path:'updateBookings', component:UpdateBookingsComponent,canActivate:[AuthGuardService]},
{path:"", redirectTo:"login", pathMatch:"full"},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
