import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  invalidCredentials:boolean=true;
  authenticated:boolean=false;

  constructor(private router:Router, private userService:UserService ){}

  loginForm!:FormGroup;

  ngOnInit():void{

    this.router.navigate(['login']);
    this.loginForm=new FormGroup(
      {
        userName:new FormControl('', [Validators.required]),
        password:new FormControl('', [Validators.required]),
      }
    )
  }

  authenticatedUser(){
    return this.userService.authenticate(this.loginForm.get('userName')?.value,this.loginForm.get('password')?.value )
  }
  async checkLogin(){
    let valid=await this.authenticatedUser();
    console.log(valid);
    
    if(valid){
       this.router.navigate(['addTrip']);
    }
    else{

      alert("invalid username or password");
      this.invalidCredentials=false;
      
    }
  }


  



}
