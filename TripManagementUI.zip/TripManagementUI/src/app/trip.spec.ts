import { Trip } from './trip';

describe('Trip', () => {
  it('should create an instance', () => {
    expect(new Trip()).toBeTruthy();
  });
});
