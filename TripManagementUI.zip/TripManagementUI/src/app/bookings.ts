import { Time } from "@angular/common"


export class Bookings {
    bookingId!: number
    noSeats!: number
    seekerId!: string
    bookingStatus!: string
    tripId!:string
}
