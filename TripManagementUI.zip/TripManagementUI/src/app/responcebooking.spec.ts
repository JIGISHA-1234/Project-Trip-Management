import { Responcebooking } from './responcebooking';

describe('Responcebooking', () => {
  it('should create an instance', () => {
    expect(new Responcebooking()).toBeTruthy();
  });
});
