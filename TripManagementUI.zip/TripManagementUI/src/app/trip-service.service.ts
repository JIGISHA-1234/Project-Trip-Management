import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Trip } from './trip';

@Injectable({
  providedIn: 'root'
})
export class TripServiceService {
  getTripById(tripId: string) {
    
  }
 

  baseURL="http://localhost:8083/api/tripmanager/new";
  // baseURL1="http://localhost:8083/api/tripmanager/trip";
  updateTripUrl="http://localhost:8083/api/tripmanager";

  constructor(private httpClient : HttpClient) { }

  addTrip(trip : Trip): Observable<Object>{
    
    return this.httpClient.post(`${this.baseURL}`,trip);

  }

  getAllTrip(): Observable<Trip[]>{

    return this.httpClient.get<Trip[]>('http://localhost:8083/api/tripmanager/trip');


  }


  updateTrips(tripId:string,trip:Trip){
    console.log("In service:"+JSON.stringify(trip));
    return this.httpClient.put<Trip>(this.updateTripUrl+"/"+tripId+"/updatetrip",trip);

  }
 
    

  

}
