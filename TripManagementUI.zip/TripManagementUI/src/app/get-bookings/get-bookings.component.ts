import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// import { Bookings } from '../bookings';
import { Responcebooking } from '../responcebooking';
import { BookingsServiceService } from '../bookings-service.service';

@Component({
  selector: 'app-get-bookings',
  templateUrl: './get-bookings.component.html',
  styleUrls: ['./get-bookings.component.css']
})
export class GetBookingsComponent implements OnInit{
  allbookings : any;
  
  constructor( private bokingsService:BookingsServiceService , private router: Router){
    this.getAllBookings();
  }
  ngOnInit(): void {
    this.getAllBookings()
  }
  getAllBookings() {
    this.bokingsService.getAllBooking().subscribe(data=>{
      this.allbookings=data;
      
      //yha pr data to allbookings transfer ni ho rha h agr allbookings ko class ka type dete



      // console.log(this.allbookings); 
    },
    error=>{
      alert("Something went wrong");
      window.location.reload();
    })

    

}


}
