import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {


  
  private url='http://localhost:8083/api/tripmanager';
  authenticatedUser!:User;
  authenticateUserBacked:User=new User();
  authenticated:boolean=false;
  users!:User[];

  constructor(private http : HttpClient,private router: Router) { }

  

  logIn(user:User){

    return firstValueFrom(this.http.post<User>(this.url+"/login",user));
    // return this.http.post<User>(this.url+"/login",user)
  }
  async authenticate(userName:string, password:string){
    this.authenticated=false
    this.authenticatedUser=new User();
    this.authenticatedUser.userName=userName;
    this.authenticatedUser.password=password;

    this.authenticateUserBacked.password=""
    this.authenticateUserBacked.userName=""

    try{
      this.authenticateUserBacked=await this.logIn(this.authenticatedUser);
      if(this.authenticatedUser.userName===this.authenticateUserBacked.userName&& this.authenticatedUser.password===this.authenticateUserBacked.password){
        this.authenticated=true;
        sessionStorage.setItem('userName', this.authenticateUserBacked.userName);
        sessionStorage.setItem('role', this.authenticateUserBacked.role);
    
      }
    }
    catch(err){

    }
  
  // this.logIn(this.authenticatedUser).subscribe({
  //   next:(data)=>{
  //     this.authenticateUserBacked=data;
  //     if(this.authenticatedUser.userName===this.authenticateUserBacked.userName&& this.authenticatedUser.password===this.authenticateUserBacked.password){
  //       this.authenticated=true;
  //       sessionStorage.setItem('userName', this.authenticateUserBacked.userName);
  //       sessionStorage.setItem('role', this.authenticateUserBacked.role);
    
  //     }
  //   }

  // })

    
  
    return this.authenticated;
  }

  isUserLoggedIn(){
    let user=sessionStorage.getItem('userName');
    let role=sessionStorage.getItem('role');
    return !(user===null && role===null);
  }

  isUserAdmin(){
    let role=sessionStorage.getItem('role');
    return (role==='User');
  }

  logOut(){
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('role');
    this.router.navigateByUrl('/login');
  }
}
