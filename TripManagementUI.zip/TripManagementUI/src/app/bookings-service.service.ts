import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { Bookings } from './bookings';
import {Responcebooking } from './responcebooking';

@Injectable({
  providedIn: 'root'
})


export class BookingsServiceService {

  
 
  baseURL="http://localhost:8083/api/tripmanager/bookRide";

  updateTripUrl="http://localhost:8083/api/tripmanager"

  constructor(private httpClient : HttpClient) {}

  addBookings(bookings:Bookings): Observable<any>{
    
    return this.httpClient.post(`${this.baseURL}`,bookings).pipe(
      catchError(this.handleError)
    );

  }

  getAllBooking(): Observable<Responcebooking[]>{

    return this.httpClient.get<Responcebooking[]>('http://localhost:8083/api/tripmanager/allbooking');


  }


  updateTrips(bookingId:number,bookings:Bookings){
    // console.log("In service:"+JSON.stringify(bookings));
    return this.httpClient.put<Bookings>(this.updateTripUrl+"/"+bookingId+"/update",bookings);

  }


  private handleError(error:HttpErrorResponse)
  {
    let message = "";
    if (error.status === 0)
    {
      console.error('An error occurred:',error.error)
    }
    else{
      // console.error(`Backend returned code $ {error.status},body was: `,error.error)
      message = `${error.error}`;
    }
    return throwError(()=> new Error(message));
  }
 

}
