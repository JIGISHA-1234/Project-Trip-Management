import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup , Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Trip } from '../trip';
import { TripServiceService } from '../trip-service.service';

@Component({
  selector: 'app-add-trip',
  templateUrl: './add-trip.component.html',
  styleUrls: ['./add-trip.component.css']
})
export class AddTripComponent implements OnInit {

      trip: Trip = new Trip();
      submitted=false;
      isCorrectDate:boolean=true;
      isSamePlace:boolean=true;
      isRideDate:boolean=true;
      isPositiveSeat:boolean=true;
      isPositiveId:boolean=true;
      isIntegerId=true;
      isIntegerSeat=true;
     constructor(private tripService:TripServiceService , private router: Router){

      
     }



  ngOnInit(): void {
    
  }
              
  addTrip(){
    
    this.addTripData();
    
  }
  addTripData(){
    
    this.tripService.addTrip(this.trip).subscribe(data=>{
      this.submitted=true;
      // this.goToListOfTripPage();
      console.log("true////")
    },
    error=>{
      // alert("Enter valid data");
      // window.location.reload();
      // this.submitted=false;
      // console.log("false/////")
    }
    )
    
  }
       
      // goToListOfTripPage(){
               
      //   this.router.navigate(['/trips'])
      // }

      onChangeDate(){
        // console.log(this.trip.rideDate)
        this.isRideDate=true;
        let dateStr=String(this.trip.rideDate)

        // new Date(,);
        // console.log()

        let dateTemp=new Date(this.trip.rideDate);
        let date=new Date(dateTemp.getFullYear(),dateTemp.getMonth(),dateTemp.getDate())
        let nowTemp=new Date();
        let dateNow=new Date(nowTemp.getFullYear(),nowTemp.getMonth(),nowTemp.getDate())

        let hoursTemp=nowTemp.getHours();
        let minTemp=nowTemp.getMinutes();
        let secTemp=nowTemp.getSeconds();
        if(date<dateNow){
          this.isCorrectDate=false;
        }
        else if(date.getFullYear()===dateNow.getFullYear()&&date.getMonth()===dateNow.getMonth()&&date.getDay()===dateNow.getDay()){
          let givenTime=this.trip.rideTime;
          let hrs=Number(String(givenTime).substring(0,2));
          let mins=Number(String(givenTime).substring(3,5));
          let time=hrs*60+mins;

          let currentTime=nowTemp.getHours()*60+nowTemp.getMinutes();

          if(time<=currentTime){
            this.isCorrectDate=false;
          }
          else{
            this.isCorrectDate=true
          }
        }
        else{
          this.isCorrectDate=true;
        }
      }

      // minDate()
      // {
      //   return new Date().toDateString().split('T')[0];
      // }
      
      samaDestination(){
         let source=this.trip.fromLoc.toLowerCase();
         
        let destination=this.trip.toLoc.toLowerCase();
      
        if(source==destination)
        {
          this.isSamePlace=false;
        }
        else{
          this.isSamePlace=true
        }

      }

      
      givePositivSeatNUmber(){
        let value=this.trip.noOfSeat;
        if(value<=0)
        {
          this.isPositiveSeat=false;
        }
        else{
          this.isPositiveSeat=true;
        }
      }
       
      givePositivId(){
        let value=this.trip.creatorUserId;
        if(value<=0)
        {
          this.isPositiveId=false;
        }
        else{
          this.isPositiveId=true;
        }
      }

      giveInteger(){
        let value:Number=this.trip.creatorUserId;
        
        
        const numberString = value.toString();
        const isFloat = /\d+\.\d+/.test(
            numberString
        );

        if(isFloat)
        {
          this.isIntegerId=false;
        }
        else{
          this.isIntegerId=true;
        }
       
      }

      giveIntegerSeat(){
        let value:Number=this.trip.noOfSeat;
        
        
        const numberString = value.toString();
        const isFloat = /\d+\.\d+/.test(
            numberString
        );

        if(isFloat)
        {
          this.isIntegerSeat=false;
        }
        else{
          this.isIntegerSeat=true;
        }
       
      }

      form={
        creatorUserId:'',
        vehicleId:'',
        rideDate:'',
        rideTime:'',
        noOfSeat:'',
        fromLoc:'',
        toLoc:''


    
      
      }

     
      
}
