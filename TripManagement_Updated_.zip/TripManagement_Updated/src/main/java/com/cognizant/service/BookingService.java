package com.cognizant.service;

import java.util.List;

import com.cognizant.model.BookRequestDTO;
import com.cognizant.model.BookResponseDTO;


public interface BookingService {
	List<BookResponseDTO>getBookingResponseModels();
	String persistBookingRequest(BookRequestDTO bookRequest);
	String updateBooking(Long Booking_Id ,BookRequestDTO bookRequest);

}
