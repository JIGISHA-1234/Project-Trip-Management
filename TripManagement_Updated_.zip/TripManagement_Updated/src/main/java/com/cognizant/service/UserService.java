package com.cognizant.service;
 
import java.util.List;
 

import com.cognizant.entities.Users;
import com.cognizant.model.usersDTO;
 
public interface UserService {
	public List<Users> listUsers();
	public usersDTO logIn(String userName, String password);
	
 
}