package com.cognizant.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.entities.Booking;
import com.cognizant.entities.Trip;
import com.cognizant.enums.BookingStatus;
import com.cognizant.enums.RideStatus;
import com.cognizant.exception.ResourceNotFoundException;
import com.cognizant.exception.StatusIsNotConsistent;
import com.cognizant.exception.seatsAreNotPresent;
import com.cognizant.model.BookRequestDTO;
import com.cognizant.model.BookResponseDTO;
import com.cognizant.repos.BookingRepos;
import com.cognizant.repos.TripRepos;

@Service("bookingServiceImpl")
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingRepos repos;

	@Autowired
	private TripRepos trepos;

	@Override
	public List<BookResponseDTO> getBookingResponseModels() {
		Iterable<Booking> bookingList = repos.findAll();
		List<BookResponseDTO> bookingResponseList = new ArrayList<BookResponseDTO>();
		for (Booking b : bookingList) {

			BookResponseDTO bookResponse = new BookResponseDTO();
			bookResponse.setNoSeats(b.getNoSeats());
			bookResponse.setBookingId(b.getBookingId());
			bookResponse.setBookingStatus(b.getBookingStatus());
			bookResponse.setSeekerId(b.getSeekerId());
//			bookResponse.setTrip(b.getTrip());
			bookResponse.setTrip(b.getTrip().getTripId());
			bookingResponseList.add(bookResponse);
		}
		return bookingResponseList;
	}

	@Override
	public String persistBookingRequest(BookRequestDTO bookRequest) {

		Booking b = new Booking();

//		Trip t=trepos.findByTripId(bookRequest.getTrip().getTripId());
		Trip t = trepos.findByTripId(bookRequest.getTripId());

		if (t == null) {
			throw new ResourceNotFoundException("TripId", "TripId", bookRequest.getTripId());
		}
		if (t.getRideStatus() != RideStatus.Planned) {
			throw new StatusIsNotConsistent("RideStatus", t.getRideStatus().toString());
		} else {

			int newSeats = t.getSeatsFilled() + bookRequest.getNoSeats();

			if (newSeats <= t.getNoOfSeat()) {
				t.setSeatsFilled(newSeats);
				trepos.save(t);
				b.setBookingId(bookRequest.getBookingId());
				b.setNoSeats(bookRequest.getNoSeats());
				b.setSeekerId(bookRequest.getSeekerId());
				b.setTrip(t);
				b.setBookingStatus(bookRequest.getBookingStatus());

				Booking bookCreated = null;
				bookCreated = repos.save(b);

				if (bookCreated != null)
					return "success";
				else
					return "fail";
			} else {
//				return "fail";
				throw  new seatsAreNotPresent();
			}
		}

	}

	@Override
	public String updateBooking(Long booking_Id, BookRequestDTO bookRequest) {

		Optional<Booking> optionalofBooking = repos.findById(booking_Id);
		Booking updatedbook = null;
		if (optionalofBooking.isPresent()) {
			Booking book = optionalofBooking.get();

			book.setBookingStatus(bookRequest.getBookingStatus());
			Optional<Trip> optionaltriptoUpdate = trepos.findById(book.getTrip().getTripId());
			if (optionaltriptoUpdate.isPresent()) {
				Trip t = optionaltriptoUpdate.get();
				if (bookRequest.getBookingStatus() == BookingStatus.Cancelled) {
					int newseats = t.getSeatsFilled() - book.getNoSeats();
					t.setSeatsFilled(newseats);
					trepos.save(t);
				}
			}
			updatedbook = repos.save(book);
			if (updatedbook != null)
				return "success";
			else
				return "fail";
		} else {
			return "fail";
		}

	}

}
