package com.cognizant.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.entities.Booking;
import com.cognizant.entities.Trip;
import com.cognizant.exception.DateNotMatched;
import com.cognizant.exception.ResourceNotFoundException;
import com.cognizant.model.TripRequestDTO;
import com.cognizant.model.TripResponseDTO;
import com.cognizant.repos.BookingRepos;
import com.cognizant.repos.TripRepos;
import com.cognizant.enums.BookingStatus;
import com.cognizant.enums.RideStatus;

@Service("tripServiceImpl")
public class TripServiceImpl implements TripService {

	@Autowired
	private TripRepos trepos;

	@Autowired
	private BookingRepos brepos;

	public List<TripResponseDTO> getTripResponseModels() {
		Iterable<Trip> tripList = trepos.findAll();
		List<TripResponseDTO> tripResponseList = new ArrayList<TripResponseDTO>();
		for (Trip t : tripList) {
			TripResponseDTO tripResponse = new TripResponseDTO();
			tripResponse.setCreatorUserId(t.getCreatorUserId());
			tripResponse.setFromLoc(t.getFromLoc());
			tripResponse.setNoOfSeat(t.getNoOfSeat());
			tripResponse.setRideDate(t.getRideDate());
			tripResponse.setRideStatus(t.getRideStatus());
			tripResponse.setRideTime(t.getRideTime());
			tripResponse.setSeatsFilled(t.getSeatsFilled());
			tripResponse.setToLoc(t.getToLoc());
			tripResponse.setTripId(t.getTripId());
			tripResponse.setVehicleId(t.getVehicleId());
			tripResponseList.add(tripResponse);
		}
		return tripResponseList;
	}

	@Override
	public String persistTripRequest(TripRequestDTO tripRequest) {
		Trip t = new Trip();
		
		
		if(tripRequest.getFromLoc().equalsIgnoreCase(tripRequest.getToLoc())) {
			return "Add different destination";
		}
		
		t.setCreatorUserId(tripRequest.getCreatorUserId());
		t.setFromLoc(tripRequest.getFromLoc().toUpperCase());
		t.setToLoc(tripRequest.getToLoc().toUpperCase());
		t.setNoOfSeat(tripRequest.getNoOfSeat());
		t.setRideDate(tripRequest.getRideDate());
		t.setRideStatus(tripRequest.getRideStatus());
		t.setRideTime(tripRequest.getRideTime());
		t.setSeatsFilled(tripRequest.getSeatsFilled());

		DateTimeFormatter Hoursformatter = DateTimeFormatter.ofPattern("HH");
		String hours = t.getRideTime().format(Hoursformatter);
		DateTimeFormatter Minutesformatter = DateTimeFormatter.ofPattern("mm");
		String minutes = t.getRideTime().format(Minutesformatter);
		String ftcOfDest = t.getToLoc().substring(0, 2);
		String ftcOfSour = t.getFromLoc().substring(0, 2);
		String tripId = hours + minutes + ftcOfSour + ftcOfDest;

		t.setTripId(tripId.toUpperCase());
		t.setVehicleId(tripRequest.getVehicleId());
		
		if((tripRequest.getRideDate()).isBefore(LocalDate.now())) {
			throw new DateNotMatched("Date",tripRequest.getRideDate());
		}
		Trip tripCreated = trepos.save(t);
		
		if (tripCreated != null)
			return "success";
		else
			return "fail";
		

	}

	@Override
	public String updateTrip(String tripId, TripRequestDTO tripRequest) {

		Optional<Trip> optionalofTrip = trepos.findById(tripId);
		Trip updatedtrip = null;
		if (optionalofTrip.isPresent()) {
			Trip trip = optionalofTrip.get();
			List<Booking> tripToUpdate = brepos.findByTrip(trip);
			if (!tripToUpdate.isEmpty()) {
				
				for (Booking b : tripToUpdate) {
					
					if (tripRequest.getRideStatus() == RideStatus.Cancelled) {
						b.setBookingStatus(BookingStatus.Cancelled);
						brepos.save(b);
					}
					if (tripRequest.getRideStatus() == RideStatus.Completed) {
						b.setBookingStatus(BookingStatus.Completed);
						brepos.save(b);
					}
				}
				trip.setRideStatus(tripRequest.getRideStatus());
				updatedtrip = trepos.save(trip);
			} else {
				trip.setRideStatus(tripRequest.getRideStatus());
				updatedtrip = trepos.save(trip);
			}

		}
		if (updatedtrip != null) {
			return "success";
		} else {
			return "fail";
		}

	}

}
