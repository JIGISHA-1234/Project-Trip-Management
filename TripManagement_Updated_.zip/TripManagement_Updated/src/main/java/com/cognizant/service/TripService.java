package com.cognizant.service;

import java.util.List;


import com.cognizant.model.TripRequestDTO;
import com.cognizant.model.TripResponseDTO;


public interface TripService {
	List<TripResponseDTO>getTripResponseModels();
	String persistTripRequest(TripRequestDTO tripRequest);
	String updateTrip(String tripId ,TripRequestDTO tripRequest);
	
}
