package com.cognizant.model;

import com.cognizant.entities.Trip;
import com.cognizant.enums.BookingStatus;

import lombok.Data;

@Data
public class BookRequestDTO {
	
	private Long bookingId;
	private int noSeats;
	private String seekerId;
	private String tripId;
	private BookingStatus bookingStatus=BookingStatus.Booked;
	
//	public String getTripId() {
//		return tripId;
//	}
//
//	public void setTripId(String tripId) {
//		this.tripId = tripId;
//	}
//
//	private String tripId;
//	
//	public BookRequestDTO() {}
//	
//	public Long getBookingId() {
//		return bookingId;
//	}
//
//
//	public int getNoSeats() {
//		return noSeats;
//	}
//
//	public void setNoSeats(int noSeats) {
//		this.noSeats = noSeats;
//	}
//
//	public String getSeekerId() {
//		return seekerId;
//	}
//
//	public void setSeekerId(String seekerId) {
//		this.seekerId = seekerId;
//	}
//
//	public BookingStatus getBookingStatus() {
//		return bookingStatus;
//	}
//
//	public void setBookingStatus(BookingStatus bookingStatus) {
//		this.bookingStatus = bookingStatus;
//	}
//	
////	public String getTrip() {
////		return trip;
////	}
////
////	public void setTrip(String trip) {
////		this.trip = trip;
////	}
//
//	@Override
//	public String toString() {
//		return "Booking [bookingId=" + bookingId + ", tripId="  + ", noSeats=" + noSeats + ", seekerId="
//				+ seekerId + ", bookingStatus=" + bookingStatus + "]";
//	}
//
//	
	

}
