package com.cognizant.model;

import java.time.LocalDate;
import java.time.LocalTime;

import com.cognizant.enums.RideStatus;

import lombok.Data;

@Data
public class TripRequestDTO {
	
	private String tripId;
	private Long creatorUserId;
	private String vehicleId;
	private LocalDate rideDate;
	private LocalTime rideTime;
	private RideStatus rideStatus=RideStatus.Planned;
	private int noOfSeat;
	private int seatsFilled;
	private String fromLoc;
	private String toLoc;
	
	
//	public TripRequestDTO() {}
//	
//	public String getTripId() {
//		return tripId;
//	}
//	public void setTripId(String tripId) {
//		this.tripId = tripId;
//	}
//	public Long getCreatorUserId() {
//		return creatorUserId;
//	}
//	public void setCreatorUserId(Long creatorUserId) {
//		this.creatorUserId = creatorUserId;
//	}
//	public String getVehicleId() {
//		return vehicleId;
//	}
//	public void setVehicleId(String vehicleId) {
//		this.vehicleId = vehicleId;
//	}
//	public LocalDate getRideDate() {
//		return rideDate;
//	}
//	public void setRideDate(LocalDate rideDate) {
//		this.rideDate = rideDate;
//	}
//	public LocalTime getRideTime() {
//		return rideTime;
//	}
//	public void setRideTime(LocalTime rideTime) {
//		this.rideTime = rideTime;
//	}
//	public RideStatus getRideStatus() {
//		return rideStatus;
//	}
//	public void setRideStatus(RideStatus rideStatus) {
//		this.rideStatus = rideStatus;
//	}
//	public int getNoOfSeat() {
//		return noOfSeat;
//	}
//	public void setNoOfSeat(int noOfSeat) {
//		this.noOfSeat = noOfSeat;
//	}
//	public int getSeatsFilled() {
//		return seatsFilled;
//	}
//	public void setSeatsFilled(int seatsFilled) {
//		this.seatsFilled = seatsFilled;
//	}
//	public String getFromLoc() {
//		return fromLoc;
//	}
//	public void setFromLoc(String fromLoc) {
//		this.fromLoc = fromLoc;
//	}
//	public String getToLoc() {
//		return toLoc;
//	}
//	public void setToLoc(String toLoc) {
//		this.toLoc = toLoc;
//	}
//
//	@Override
//	public String toString() {
//		return "TripRequest [tripId=" + tripId + ", creatorUserId=" + creatorUserId + ", vehicleId=" + vehicleId
//				+ ", rideDate=" + rideDate + ", rideTime=" + rideTime + ", rideStatus=" + rideStatus + ", noOfSeat="
//				+ noOfSeat + ", seatsFilled=" + seatsFilled + ", fromLoc=" + fromLoc + ", toLoc=" + toLoc + "]";
//	}
//	
//	
	
	
	
	
}
