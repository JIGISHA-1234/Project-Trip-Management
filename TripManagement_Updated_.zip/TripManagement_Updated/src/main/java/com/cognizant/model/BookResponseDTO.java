package com.cognizant.model;

import com.cognizant.entities.Trip;
import com.cognizant.enums.BookingStatus;

import lombok.Data;

@Data
public class BookResponseDTO {
	private Long bookingId;
	private int noSeats;
	private String seekerId;
	private BookingStatus bookingStatus;
	private String trip;
	
//	public BookResponseDTO() {}
//	
//	public Long getBookingId() {
//		return bookingId;
//	}
//
//
//	public void setBookingId(Long bookingId) {
//		this.bookingId = bookingId;
//	}
//
//	public int getNoSeats() {
//		return noSeats;
//	}
//
//	public void setNoSeats(int noSeats) {
//		this.noSeats = noSeats;
//	}
//
//	public String getSeekerId() {
//		return seekerId;
//	}
//
//	public void setSeekerId(String seekerId) {
//		this.seekerId = seekerId;
//	}
//
//	public BookingStatus getBookingStatus() {
//		return bookingStatus;
//	}
//
//	public void setBookingStatus(BookingStatus bookingStatus) {
//		this.bookingStatus = bookingStatus;
//	}
//	
//	public String getTrip() {
//		return trip;
//	}
//
//	public void setTrip(String trip) {
//		this.trip = trip;
//	}
//
//	@Override
//	public String toString() {
//		return "Booking [bookingId=" + bookingId + ", tripId="  + ", noSeats=" + noSeats + ", seekerId="
//				+ seekerId + ", bookingStatus=" + bookingStatus + "]";
//	}
//	
//	


}
