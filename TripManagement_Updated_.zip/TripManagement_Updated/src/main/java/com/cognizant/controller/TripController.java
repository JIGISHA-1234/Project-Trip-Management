package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.BookRequestDTO;
import com.cognizant.model.BookResponseDTO;
import com.cognizant.model.TripRequestDTO;
import com.cognizant.model.TripResponseDTO;
import com.cognizant.model.usersDTO;
import com.cognizant.service.BookingService;
import com.cognizant.service.TripService;
import com.cognizant.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/tripmanager")
@CrossOrigin(origins = "http://localhost:4200")
@Tag(name="Employees",description = "Employee Rest API")
public class TripController {
	
	
	@Autowired
	private TripService tripService;
	
	@Autowired
	private BookingService bookingService;
	@Autowired
	private UserService userService;
	
	@Operation(description = "Retrieve All Resource of Type Trip")
	
	
	@GetMapping("/trip")
	public ResponseEntity<?> handleGetAllTrips(){
		List<TripResponseDTO> responseList=tripService.getTripResponseModels();
		ResponseEntity<List<TripResponseDTO>> responseEntity=null;
		if(!responseList.isEmpty()) {
			responseEntity=new ResponseEntity<List<TripResponseDTO>>(responseList,HttpStatus.OK);//display trip
		}else {
			responseEntity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	
	@PostMapping("/new")
	public ResponseEntity<?> persistTrip(@RequestBody TripRequestDTO tripRequest){
		String result=tripService.persistTripRequest(tripRequest);//create new trip
		if(result.equals("success")) {
			return new ResponseEntity<>(HttpStatus.CREATED);

		}else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@GetMapping("/allbooking")
	public ResponseEntity<?> handleGetAllBooking(){
		List<BookResponseDTO> responseList=bookingService.getBookingResponseModels();
		ResponseEntity<List<BookResponseDTO>> responseEntity=null;
		if(!responseList.isEmpty()) {
			responseEntity=new ResponseEntity<List<BookResponseDTO>>(responseList,HttpStatus.OK);//display all booking
		}else {
			responseEntity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	
	@PostMapping("/bookRide")
	public ResponseEntity<?> persistBooking(@RequestBody BookRequestDTO bookRequest){
		String result=bookingService.persistBookingRequest(bookRequest);
		if(result.equals("success")) {
			return new ResponseEntity<>(HttpStatus.CREATED);
		}else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);//create new book ride
		}
		
	}
	
	@PutMapping("/{Booking_id}/update")
	public ResponseEntity<?> updateBooking(@PathVariable Long Booking_id ,@RequestBody BookRequestDTO bookRequest){
		String result = bookingService.updateBooking(Booking_id, bookRequest);
		if(result.equals("success")) {
			return new ResponseEntity<>(HttpStatus.CREATED);    //update booking
		}else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	
	
	@PutMapping("/{tripId}/updatetrip")
	public ResponseEntity<?> updateTrip(@PathVariable String tripId ,@RequestBody TripRequestDTO tripRequest){
		String result = tripService.updateTrip(tripId, tripRequest);
		if(result.equals("success")) {
			return new ResponseEntity<>(HttpStatus.CREATED);
		}else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);  //update trip
		}
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody usersDTO userRequest){
		usersDTO user = userService.logIn(userRequest.getUserName(), userRequest.getPassword());
		if(user.getUserName().isEmpty()) {
			return new ResponseEntity<>(user,HttpStatus.BAD_REQUEST);
		}
		else {
			return new ResponseEntity<>(user,HttpStatus.OK);
		}
	}
	


}
