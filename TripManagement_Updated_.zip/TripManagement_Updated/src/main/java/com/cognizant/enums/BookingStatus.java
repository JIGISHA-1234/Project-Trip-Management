package com.cognizant.enums;

public enum BookingStatus {
	Booked,Cancelled,Completed
}
