package com.cognizant.enums;

public enum RideStatus {
	Planned,
	Started,
	Completed,
	Cancelled

}
