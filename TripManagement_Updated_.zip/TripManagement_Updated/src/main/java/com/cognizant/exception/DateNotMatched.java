package com.cognizant.exception;

import java.time.LocalDate;
 
import lombok.Getter;

import lombok.Setter;
 

@Getter
@Setter
public class DateNotMatched extends RuntimeException {

	String fieldName;

	LocalDate fieldValue;




	public DateNotMatched(String fieldName, LocalDate fieldValue) {

		super(String.format("Past Date cannot be Proccessed %s: %s",fieldName,fieldValue));

		this.fieldName = fieldName;

		this.fieldValue = fieldValue;

	}


}

