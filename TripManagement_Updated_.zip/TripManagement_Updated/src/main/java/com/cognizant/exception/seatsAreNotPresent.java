package com.cognizant.exception;

public class seatsAreNotPresent extends RuntimeException{
	
	public seatsAreNotPresent(){
		super(" Seats are not present");
	}
	

}
