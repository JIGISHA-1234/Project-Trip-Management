package com.cognizant.exception;

 
import lombok.Getter;

import lombok.Setter;
 
@Getter
@Setter
public class ResourceNotFoundException extends RuntimeException {

	String resourceName;

	String fieldName;

	String fieldValue;



	public ResourceNotFoundException(String resourceName, String fieldName, String tripId) {

		super(String.format("%s not found with %s : %s",resourceName,fieldName,tripId));

		this.resourceName = resourceName;

		this.fieldName = fieldName;

		this.fieldValue = tripId;

	}

//	public ResourceNotFoundException(String resourceName, String fieldName, LocalDate date) {
//
//		super(String.format("%s not found with %s : %s",resourceName,fieldName,date));
//
//		this.resourceName = resourceName;
//
//		this.fieldName = fieldName;
//
//
//	}

}

