package com.cognizant.repos;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.entities.Booking;
import com.cognizant.entities.Trip;
import com.cognizant.model.TripRequestDTO;

import java.util.List;
import java.util.Optional;





@Repository
public interface BookingRepos extends CrudRepository<Booking, Long> {

	List<Booking> findByTrip(Trip trip);

	



}
