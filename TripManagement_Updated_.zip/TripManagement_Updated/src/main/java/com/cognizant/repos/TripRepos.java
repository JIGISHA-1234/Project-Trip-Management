package com.cognizant.repos;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.entities.Trip;
import java.util.List;

@Repository
public interface TripRepos extends CrudRepository<Trip, String> {
	Trip findByTripId(String tripId);
}
