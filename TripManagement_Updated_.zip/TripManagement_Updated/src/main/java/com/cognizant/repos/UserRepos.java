package com.cognizant.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cognizant.entities.Users;

public interface UserRepos extends JpaRepository<Users,String>{


}
