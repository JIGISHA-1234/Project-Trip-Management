package com.cognizant.main;

//import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
//import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
//
//import javax.validation.ConstraintViolation;
//import javax.validation.ConstraintViolationException;
//import javax.validation.Path;
//import javax.validation.metadata.ConstraintDescriptor;

//import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.context.properties.bind.BindResult;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.support.GenericWebApplicationContext;

import com.cognizant.TripManagementApplication;
import com.cognizant.controller.TripController;
import com.cognizant.entities.Trip;
import com.cognizant.model.BookRequestDTO;
import com.cognizant.model.BookResponseDTO;
import com.cognizant.model.TripRequestDTO;
import com.cognizant.model.TripResponseDTO;
import com.cognizant.repos.TripRepos;
import com.cognizant.service.BookingService;
import com.cognizant.service.TripService;
import com.cognizant.service.TripServiceImpl;
import com.cognizant.enums.BookingStatus;
import com.cognizant.enums.RideStatus;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.fasterxml.jackson.databind.ObjectMapper;


@SpringBootTest(classes=TripManagementApplication.class)
public class TestController {
	
    private MockMvc mockMvc;

	@Mock
	private TripService tripService;
	
	@Mock
	private BookingService bookService;

	
	@InjectMocks
	private TripController tripController;
	
//	@Mock
//	private RestTemplate restTemplate;
	
//	@Autowired
//	private LocalValidatorFactoryBean validator;
//	private MockRestServiceServer mockServer;
//	private RestTemplate template;
//	private ObjectMapper mapper=new ObjectMapper();
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
//		mockMvc=MockMvcBuilders.standaloneSetup(tripController).build();
//		template=new RestTemplate();
//		mockServer=MockRestServiceServer.createServer(template);
	}
	
	@Test
	void handleGetAllTrip_positiveReturnValue() {
		try {
		List<TripResponseDTO> mockListOfTripResponse=new ArrayList<>();
		TripResponseDTO tripResponse=new TripResponseDTO();
		tripResponse.setTripId("234");
		tripResponse.setCreatorUserId(001L);
		tripResponse.setVehicleId("MP07GA6442");
		tripResponse.setRideDate(LocalDate.of(2024, Month.FEBRUARY, 27));
		tripResponse.setRideTime(LocalTime.parse("15:28:35"));
		tripResponse.setRideStatus(RideStatus.Planned);
		tripResponse.setNoOfSeat(63);
		tripResponse.setSeatsFilled(32);
		tripResponse.setFromLoc("PUNE");
		tripResponse.setToLoc("GWALIOR");
		mockListOfTripResponse.add(tripResponse);
		when(tripService.getTripResponseModels()).thenReturn(mockListOfTripResponse);
		
		ResponseEntity<?> responseEntity=tripController.handleGetAllTrips();
		List<TripResponseDTO> actual=(List<TripResponseDTO>)responseEntity.getBody();
		assertTrue(actual.size()>0);
		}catch(Exception e) {
			assertTrue(false);
		}
	}

	@Test
	void handleGetAllTrip_NegativeReturnValue() {
		try {
		List<TripResponseDTO> mockListOfTripResponse=new ArrayList<>();
		when(tripService.getTripResponseModels()).thenReturn(mockListOfTripResponse);
		
		ResponseEntity<?> responseEntity=tripController.handleGetAllTrips();
		assertNull(responseEntity.getBody());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	void handleGetAllTrip_positiveStatusCode() {
		try {
		List<TripResponseDTO> mockListOfTripResponse=new ArrayList<>();
		TripResponseDTO tripResponse=new TripResponseDTO();
		tripResponse.setTripId("234");
		tripResponse.setCreatorUserId(001L);
		tripResponse.setVehicleId("MP07GA6442");
		tripResponse.setRideDate(LocalDate.of(2024, Month.FEBRUARY, 27));
		tripResponse.setRideTime(LocalTime.parse("15:28:35"));
		tripResponse.setRideStatus(RideStatus.Planned);
		tripResponse.setNoOfSeat(63);
		tripResponse.setSeatsFilled(32);
		tripResponse.setFromLoc("PUNE");
		tripResponse.setToLoc("GWALIOR");
		mockListOfTripResponse.add(tripResponse);
		when(tripService.getTripResponseModels()).thenReturn(mockListOfTripResponse);
		
		ResponseEntity<?> responseEntity=tripController.handleGetAllTrips();
		
		assertEquals(200,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	@Test
	void handleGetAllTrip_negativeStatusCode() {
		try {
		List<TripResponseDTO> mockListOfTripResponse=new ArrayList<>();
		when(tripService.getTripResponseModels()).thenReturn(mockListOfTripResponse);
		ResponseEntity<?> responseEntity=tripController.handleGetAllTrips();
		assertEquals(400,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	

	
	/*
	@Test
	public void persistTripWhenEmpNameIsValid() {
		EmployeeDTO employeeDTO=new EmployeeDTO();
		employeeDTO.setEmpId(1001);
		employeeDTO.setEmpName("Sabbir");
		employeeDTO.setEmpSalary(34000);
		employeeDTO.setEmpDesignation("Trainer");
		
		validator.validateProperty(employeeDTO, "empName")
		.stream()
		.forEach((constraintViolation)->assertNull(constraintViolation));
	}
	@Test
	public void persistEmployeeWhenEmpNameIsNotValid() {
		EmployeeDTO employeeDTO=new EmployeeDTO();
		employeeDTO.setEmpId(1001);
		employeeDTO.setEmpName("");
		employeeDTO.setEmpSalary(34000);
		employeeDTO.setEmpDesignation("Trainer");
		
		validator.validateProperty(employeeDTO, "empName")
		.stream()
		.forEach((constraintViolation)->assertNotNull(constraintViolation));
	}
	
	
	@Test
	public void persistEmployeeWhenEmpNameIsNotValidMessage() {
		EmployeeDTO employeeDTO=new EmployeeDTO();
		employeeDTO.setEmpId(1001);
		employeeDTO.setEmpName("");
		employeeDTO.setEmpSalary(34000);
		employeeDTO.setEmpDesignation("Trainer");
		
		validator.validateProperty(employeeDTO, "empName")
		.stream()
		.forEach((constraintViolation)->assertEquals("Employee Name cannot be blank",constraintViolation.getMessage()));
	}
	
	public void persistEmployeeWhenEmpDesignationIsValid() {
		EmployeeDTO employeeDTO=new EmployeeDTO();
		employeeDTO.setEmpId(1001);
		employeeDTO.setEmpName("Sabbir");
		employeeDTO.setEmpSalary(34000);
		employeeDTO.setEmpDesignation("Trainer");
		
		validator.validateProperty(employeeDTO, "empDesignation")
		.stream()
		.forEach((constraintViolation)->assertNull(constraintViolation));
	}
	public void persistEmployeeWhenEmpDesignationIsNotValidLessThan3Characters() {
		EmployeeDTO employeeDTO=new EmployeeDTO();
		employeeDTO.setEmpId(1001);
		employeeDTO.setEmpName("Sabbir");
		employeeDTO.setEmpSalary(34000);
		employeeDTO.setEmpDesignation("Tr");
		
		validator.validateProperty(employeeDTO, "empDesignation")
		.stream()
		.forEach((constraintViolation)->assertNotNull(constraintViolation));
	}
	public void persistEmployeeWhenEmpDesignationIsNotValidGreaterThan10Characters() {
		EmployeeDTO employeeDTO=new EmployeeDTO();
		employeeDTO.setEmpId(1001);
		employeeDTO.setEmpName("Sabbir");
		employeeDTO.setEmpSalary(34000);
		employeeDTO.setEmpDesignation("Senior Software Engineer");
		
		validator.validateProperty(employeeDTO, "empDesignation")
		.stream()
		.forEach((constraintViolation)->assertNotNull(constraintViolation));
	}
	@Test
	public void persistEmployeeWhenEmpDesignationIsNotValidMessage() {
		EmployeeDTO employeeDTO=new EmployeeDTO();
		employeeDTO.setEmpId(1001);
		employeeDTO.setEmpName("");
		employeeDTO.setEmpSalary(34000);
		employeeDTO.setEmpDesignation("Trainer");
		
		validator.validateProperty(employeeDTO, "empDesignation")
		.stream()
		.forEach((constraintViolation)->assertEquals("Designation must have minimum 3 characters and maximum 10 characters",constraintViolation.getMessage()));
	}
	
	@Test
	public void persistEmployeeWhenEmpIdIsNotValid() {
		EmployeeDTO employeeDTO=new EmployeeDTO();
		employeeDTO.setEmpId(1001);
		employeeDTO.setEmpName("Sabbir");
		employeeDTO.setEmpSalary(34000);
		employeeDTO.setEmpDesignation("Trainer");
		
		LocalValidatorFactoryBean mockOfLocalValidatorFactoryBean=Mockito.mock(LocalValidatorFactoryBean.class);
		Set<ConstraintViolation<EmployeeDTO>> setOfConstraintViolation=new HashSet<>();
		setOfConstraintViolation.add(new ConstraintViolation<EmployeeDTO>() {

			@Override
			public String getMessage() {
				// TODO Auto-generated method stub
				return "Employee ID already exists";
			}

			@Override
			public String getMessageTemplate() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public EmployeeDTO getRootBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Class<EmployeeDTO> getRootBeanClass() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getLeafBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object[] getExecutableParameters() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getExecutableReturnValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Path getPropertyPath() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getInvalidValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ConstraintDescriptor<?> getConstraintDescriptor() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public <U> U unwrap(Class<U> type) {
				// TODO Auto-generated method stub
				return null;
			}
			
		});
		when(mockOfLocalValidatorFactoryBean.validateProperty(employeeDTO, "empId")).thenReturn(setOfConstraintViolation);
		mockOfLocalValidatorFactoryBean.validateProperty(employeeDTO, "empId")
		.stream()
		.forEach((constraintViolation)->assertNotNull(constraintViolation));
	}
	
	@Test
	public void persistEmployeeWhenEmpIdIsNotValidMessage() {
		EmployeeDTO employeeDTO=new EmployeeDTO();
		employeeDTO.setEmpId(1001);
		employeeDTO.setEmpName("Sabbir");
		employeeDTO.setEmpSalary(34000);
		employeeDTO.setEmpDesignation("Trainer");
		
		LocalValidatorFactoryBean mockOfLocalValidatorFactoryBean=Mockito.mock(LocalValidatorFactoryBean.class);
		Set<ConstraintViolation<EmployeeDTO>> setOfConstraintViolation=new HashSet<>();
		setOfConstraintViolation.add(new ConstraintViolation<EmployeeDTO>() {

			@Override
			public String getMessage() {
				// TODO Auto-generated method stub
				return "Employee ID already exists";
			}

			@Override
			public String getMessageTemplate() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public EmployeeDTO getRootBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Class<EmployeeDTO> getRootBeanClass() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getLeafBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object[] getExecutableParameters() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getExecutableReturnValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Path getPropertyPath() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getInvalidValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ConstraintDescriptor<?> getConstraintDescriptor() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public <U> U unwrap(Class<U> type) {
				// TODO Auto-generated method stub
				return null;
			}
			
		});
		when(mockOfLocalValidatorFactoryBean.validateProperty(employeeDTO, "empId")).thenReturn(setOfConstraintViolation);
		mockOfLocalValidatorFactoryBean.validateProperty(employeeDTO, "empId")
		.stream()
		.forEach((constraintViolation)->assertEquals("Employee ID already exists",constraintViolation.getMessage()));
	}
	*/
	@Test
	void persistTripPositiveReturnValue() {
		TripRequestDTO t = new TripRequestDTO();
		
		t.setTripId("8900PUGW");
		t.setCreatorUserId(001L);
		t.setVehicleId("MP07GA6442");
		t.setRideDate(LocalDate.of(2024, Month.FEBRUARY, 27));
		t.setRideTime(LocalTime.parse("15:28:35"));
		t.setRideStatus(RideStatus.Planned);
		t.setNoOfSeat(63);
		t.setSeatsFilled(32);
		t.setFromLoc("PUNE");
		t.setToLoc("GWALIOR");
		when(tripService.persistTripRequest(t)).thenReturn("success");
		
		ResponseEntity<?> responseEntity=tripController.persistTrip(t);
		assertEquals(201,responseEntity.getStatusCodeValue());
	}
	@Test
	void persistTripNegativeReturnValue() {
		TripRequestDTO t = new TripRequestDTO();
		
		t.setTripId("8900PUGW");
		//t.setCreatorUserId(001L);
		t.setVehicleId("MP07GA6442");
		t.setRideDate(LocalDate.of(2024, Month.FEBRUARY, 27));
		t.setRideTime(LocalTime.parse("15:28:35"));
		t.setRideStatus(RideStatus.Planned);
		t.setNoOfSeat(63);
		t.setSeatsFilled(32);
		t.setFromLoc("PUNE");
		t.setToLoc("GWALIOR");
		when(tripService.persistTripRequest(t)).thenReturn("fail");
		
		ResponseEntity<?> responseEntity=tripController.persistTrip(t);
		assertEquals(400,responseEntity.getStatusCodeValue());
	}
	

	
	@Test
	void handleGetAllBooking_positiveReturnValue() {
		try {
		List<BookResponseDTO> mockListOfBookingResponse=new ArrayList<>();
		BookResponseDTO b=new BookResponseDTO();
		b.setTrip("0900PUGW");
		b.setBookingId(1L);
		b.setNoSeats(5);
		b.setSeekerId("RESH00");
		b.setBookingStatus(BookingStatus.Booked);
		mockListOfBookingResponse.add(b);
		when(bookService.getBookingResponseModels()).thenReturn(mockListOfBookingResponse);
		
		ResponseEntity<?> responseEntity=tripController.handleGetAllBooking();
		List<BookResponseDTO> actual=(List<BookResponseDTO>)responseEntity.getBody();
		assertTrue(actual.size()>0);
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	
	@Test
	void handleGetAllBooking_NegativeReturnValue() {
		try {
		List<BookResponseDTO> mockListOfBookingResponse=new ArrayList<>();
		when(bookService.getBookingResponseModels()).thenReturn(mockListOfBookingResponse);
		
		ResponseEntity<?> responseEntity=tripController.handleGetAllBooking();
		assertNull(responseEntity.getBody());
		}catch(Exception e) {
			assertTrue(false);
		}
	}
	@Test
	void persistBookingPositiveReturnValue() {
		BookRequestDTO b = new BookRequestDTO();
		
		b.setTripId("0900PUGW");
		b.setBookingId(1L);
		b.setNoSeats(5);
		b.setSeekerId("RESH00");
		b.setBookingStatus(BookingStatus.Booked);
		when(bookService.persistBookingRequest(b)).thenReturn("success");
		
		ResponseEntity<?> responseEntity=tripController.persistBooking(b);
		assertEquals(201,responseEntity.getStatusCodeValue());
	}
	@Test
	void persistBookingNegativeReturnValue() {
		BookRequestDTO b = new BookRequestDTO();
		
		b.setTripId("0900PUGW");
		b.setBookingId(1L);
		b.setNoSeats(5);
		b.setSeekerId("RESH00");
		b.setBookingStatus(BookingStatus.Booked);
		when(bookService.persistBookingRequest(b)).thenReturn("fail");
		
		ResponseEntity<?> responseEntity=tripController.persistBooking(b);
		assertEquals(400,responseEntity.getStatusCodeValue());
	}
	
	
	@Test
	public void UpdateBookingRequestStatus_Positive() {
	
			BookRequestDTO updatedDto = new BookRequestDTO();
			when(bookService.updateBooking(1L,updatedDto)).thenReturn("success");
			ResponseEntity<?> responseEntity= tripController.updateBooking(1L,updatedDto);
			assertEquals(201, responseEntity.getStatusCodeValue());
	}
	
	@Test
	public void UpdateBookingRequestStatus_Negative() {
	
			BookRequestDTO updatedDto = new BookRequestDTO();
			when(bookService.updateBooking(1L,updatedDto)).thenReturn("fail");
			ResponseEntity<?> responseEntity= tripController.updateBooking(1L,updatedDto);
			assertEquals(400, responseEntity.getStatusCodeValue());
	}
	@Test
	public void UpdateTripRequestStatus_Positive() {
	
			TripRequestDTO updatedDto = new TripRequestDTO();
			when(tripService.updateTrip("8900PUGW", updatedDto)).thenReturn("success");
			ResponseEntity<?> responseEntity= tripController.updateTrip("8900PUGW", updatedDto);
			assertEquals(201, responseEntity.getStatusCodeValue());
	}
	@Test
	public void UpdateTripRequestStatus_Negative() {
		
		TripRequestDTO updatedDto = new TripRequestDTO();
		when(tripService.updateTrip("8900PUGW", updatedDto)).thenReturn("fail");
		ResponseEntity<?> responseEntity= tripController.updateTrip("8900PUGW", updatedDto);
		assertEquals(400, responseEntity.getStatusCodeValue());
}
	
}
