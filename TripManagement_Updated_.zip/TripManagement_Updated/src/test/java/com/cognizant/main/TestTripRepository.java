package com.cognizant.main;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.TripManagementApplication;
import com.cognizant.entities.Trip;
import com.cognizant.enums.RideStatus;
import com.cognizant.repos.TripRepos;
@DataJpaTest
@ContextConfiguration(classes = TripManagementApplication.class)

public class TestTripRepository {
	@Autowired
	private TripRepos tripRepos;
	@Autowired
	private TestEntityManager entityManager;
	@Test
	public void testFindAllPositive() {
		Trip t=new Trip();		
		t.setTripId("00PUGW");
		t.setCreatorUserId(001L);
		t.setVehicleId("MP07GA6442");
		t.setRideDate(LocalDate.of(2024,Month.FEBRUARY,27));
		t.setRideTime(LocalTime.parse("15:28:35"));
		t.setRideStatus(RideStatus.Planned);
		t.setNoOfSeat(63);
		t.setSeatsFilled(32);
		t.setFromLoc("PUNE");
		t.setToLoc("GWALIOR");
		entityManager.persist(t);
		Iterable<Trip> it=tripRepos.findAll();
		assertTrue(it.iterator().hasNext());
	}
	@Test
	public void testFindAllNegative() {
		Iterable<Trip> it=tripRepos.findAll();
		assertFalse(!it.iterator().hasNext());
	}
	
	
	@Test
	public void testFindByIdPositive() {
		Trip t=new Trip();
		t.setTripId("1000PUGW");
//		t.setCreatorUserId(001);
		t.setVehicleId("MP07GA6442");
		t.setRideDate(LocalDate.of(2024,Month.FEBRUARY,27));
		t.setRideTime(LocalTime.parse("15:28:35"));
		t.setRideStatus(RideStatus.Planned);
		t.setNoOfSeat(63);
		t.setSeatsFilled(32);
		t.setFromLoc("PUNE");
		t.setToLoc("GWALIOR");
		entityManager.persist(t);
		Optional<Trip> employee=tripRepos.findById("1000PUGW");
		assertTrue(employee.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<Trip> employee=tripRepos.findById("1000PUGW");
		assertTrue(!employee.isPresent());
	}
	
	@Test
	public void testSavePositive() {
		Trip t=new Trip();
		t.setTripId("1100PUGW");
//		t.setCreatorUserId(001);
		t.setVehicleId("MP07GA6442");
		t.setRideDate(LocalDate.of(2024,Month.FEBRUARY,27));
		t.setRideTime(LocalTime.parse("15:28:35"));
		t.setRideStatus(RideStatus.Planned);
		t.setNoOfSeat(63);
		t.setSeatsFilled(32);
		t.setFromLoc("PUNE");
		t.setToLoc("GWALIOR");
		
		tripRepos.save(t);
		Optional<Trip> employee=tripRepos.findById("1100PUGW");
		assertTrue(employee.isPresent());
	}
	@Test
	public void testDeletePositive() {
		Trip t=new Trip();
		t.setTripId("8900PUGW");
//		t.setCreatorUserId(001);
		t.setVehicleId("MP07GA6442");
		t.setRideDate(LocalDate.of(2024,Month.FEBRUARY,27));
		t.setRideTime(LocalTime.parse("15:28:35"));
		t.setRideStatus(RideStatus.Planned);
		t.setNoOfSeat(63);
		t.setSeatsFilled(32);
		t.setFromLoc("PUNE");
		t.setToLoc("GWALIOR");
		entityManager.persist(t);
		tripRepos.delete(t);
		Optional<Trip> employee=tripRepos.findById("8900PUGW");
		assertTrue(!employee.isPresent());
	}
	
	@Test
	public void testDeleteNegative() {
		Trip t=new Trip();
		t.setTripId("8900PUGW");
//		t.setCreatorUserId(001);
		t.setVehicleId("MP07GA6442");
		t.setRideDate(LocalDate.of(2024,Month.FEBRUARY,27));
		t.setRideTime(LocalTime.parse("15:28:35"));
		t.setRideStatus(RideStatus.Planned);
		t.setNoOfSeat(63);
		t.setSeatsFilled(32);
		t.setFromLoc("PUNE");
		t.setToLoc("GWALIOR");
		entityManager.persist(t);
		System.out.println(tripRepos.count());
		tripRepos.deleteById("76333");
		if(tripRepos.count()==3) {
			assertTrue(true);
		}else {
			assertTrue(false);
		}
	}

}
