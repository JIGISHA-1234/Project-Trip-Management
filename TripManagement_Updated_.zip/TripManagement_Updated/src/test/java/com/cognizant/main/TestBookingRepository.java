package com.cognizant.main;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.TripManagementApplication;
import com.cognizant.entities.Booking;
import com.cognizant.entities.Trip;
import com.cognizant.enums.BookingStatus;
import com.cognizant.repos.BookingRepos;

@DataJpaTest
@ContextConfiguration(classes = TripManagementApplication.class)
public class TestBookingRepository {

	@Autowired
	private BookingRepos bookingRepos;
	@Autowired
	private TestEntityManager entityManager;
//	@Test
//	public void testFindAllPositive() {
//		Booking t=new Booking();	
//		t.setTrip(new Trip());
//		t.setNoSeats(5);
//		t.setSeekerId("RESH00");
//		t.setBookingStatus(BookingStatus.Booked);
//		entityManager.persist(t);
//		Iterable<Booking> it=bookingRepos.findAll();
//		assertTrue(it.iterator().hasNext());
//	}
	@Test
	public void testFindAllNegative() {
		Iterable<Booking> it=bookingRepos.findAll();
		assertFalse(!it.iterator().hasNext());
	}
	
	
	@Test
	public void testFindByIdPositive() {
		Booking t=new Booking();		
		t.setTrip(new Trip());
		t.setNoSeats(5);
		t.setSeekerId("RESH00");
		t.setBookingStatus(BookingStatus.Booked);
		entityManager.persist(t);
		Optional<Booking> employee=bookingRepos.findById(1L);
		assertTrue(employee.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<Booking> employee=bookingRepos.findById(7L);
		assertTrue(!employee.isPresent());
	}
	
	@Test
	public void testSavePositive() {
		Booking t=new Booking();		
		t.setTrip(new Trip());
		t.setNoSeats(5);
		t.setSeekerId("RESH00");
		t.setBookingStatus(BookingStatus.Booked);
		bookingRepos.save(t);
		Optional<Booking> employee=bookingRepos.findById(1L);
		assertTrue(employee.isPresent());
	}
	@Test
	public void testDeletePositive() {
		Booking t=new Booking();		
		t.setTrip(new Trip());
		t.setNoSeats(5);
		t.setSeekerId("RESH00");
		t.setBookingStatus(BookingStatus.Booked);
		entityManager.persist(t);
		bookingRepos.delete(t);
		Optional<Booking> employee=bookingRepos.findById(6L);
		assertTrue(!employee.isPresent());
	}

}
