package com.cognizant.main;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import com.cognizant.TripManagementApplication;
import com.cognizant.controller.TripController;
import com.cognizant.entities.Trip;
import com.cognizant.repos.TripRepos;


@SpringBootTest(classes=TripManagementApplication.class)
public class TripManagementApplicationTests {
	
	@Autowired
	private TripController tripController;
	
    @Test
	public void contextLoads() {
		assertNotNull(tripController);
	}
}
//
//@SpringBootTest
//class TripManagementApplicationTests {
//	
//	@Autowired
//	ApplicationContext context;
//
//	@Test
//	public void createTrip() {
//		TripRepos repo = context.getBean(TripRepos.class);
//		Trip t = new Trip();
//		
//		
//		t.setTripId("0900PUGW");
//		t.setCreatorUserId(001);
//		t.setVehicleId("MP07GA6442");
//		t.setRideDate("23-03-2024");
//		t.setRideTime("0900");
//		t.setRideStatus("PLANED");
//		t.setNoOfSeat(63);
//		t.setSeatsFilled(32);
//		t.setFromLoc("PUNE");
//		t.setToLoc("GWALIOR");
//		
//		repo.save(t);
//	}
//
//}
