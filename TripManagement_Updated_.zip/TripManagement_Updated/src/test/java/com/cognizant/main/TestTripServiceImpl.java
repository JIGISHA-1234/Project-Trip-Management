package com.cognizant.main;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import org.springframework.test.context.junit4.SpringRunner;

import com.cognizant.entities.Trip;
import com.cognizant.enums.RideStatus;
import com.cognizant.model.TripRequestDTO;
import com.cognizant.model.TripResponseDTO;
import com.cognizant.repos.BookingRepos;
import com.cognizant.repos.TripRepos;
import com.cognizant.service.TripServiceImpl;

class TestTripServiceImpl {

	
	@Mock
	private TripRepos tripRepos;
	
	@Mock
	private BookingRepos bookingRepos;
	


	@InjectMocks
	private TripServiceImpl tripServiceImpl;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@AfterEach
	void tearDown() throws Exception {
		
	}

	@Test
	void testUpdateTripRequestStatus_Positive() {
		try {
		Trip t=new Trip();
		t.setTripId("8900PUGW");
		t.setCreatorUserId(001L);
		t.setVehicleId("MP07GA6442");
		t.setRideDate(LocalDate.of(2024,Month.FEBRUARY,27));
		t.setRideTime(LocalTime.parse("15:28:35"));
		t.setRideStatus(RideStatus.Planned);
		t.setNoOfSeat(63);
		t.setSeatsFilled(32);
		t.setFromLoc("PUNE");
		t.setToLoc("GWALIOR");
		Optional<Trip> optionalOfTrip=Optional.of(t);
		when(tripRepos.findById("8900PUGW")).thenReturn(optionalOfTrip);
		
		
		TripRequestDTO updatedDto=new TripRequestDTO();
		updatedDto.setRideStatus(RideStatus.Cancelled);
		
		Trip tnew= new Trip();
		tnew.setRideStatus(updatedDto.getRideStatus());
		tripRepos.save(tnew);
		when(tripRepos.save(t)).thenReturn(tnew);

		String actual=tripServiceImpl.updateTrip("8900PUGW", updatedDto);
		assertEquals("success",actual);
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	@Test
	public void getTripResponseModels_positiveWhenModelIsFound() {
		try {
		Iterable<Trip> iterableMock=Mockito.mock(Iterable.class);
		when(tripRepos.findAll()).thenReturn(iterableMock);
		Iterator<Trip> iteratorMock=Mockito.mock(Iterator.class);
		when(iterableMock.iterator()).thenReturn(iteratorMock);
		when(iteratorMock.hasNext()).thenReturn(true).thenReturn(false);
		Trip tripMock=Mockito.mock(Trip.class);
		when(iteratorMock.next()).thenReturn(tripMock);
		when(tripMock.getTripId()).thenReturn("0900PUGW");
		when(tripMock.getCreatorUserId()).thenReturn(3L);
		when(tripMock.getFromLoc()).thenReturn("Pune");
		when(tripMock.getToLoc()).thenReturn("Gwalior");
		when(tripMock.getNoOfSeat()).thenReturn(45);
		when(tripMock.getSeatsFilled()).thenReturn(4);
		when(tripMock.getRideDate()).thenReturn(LocalDate.of(2024,Month.FEBRUARY,27));
		when(tripMock.getRideStatus()).thenReturn(RideStatus.Planned);
		when(tripMock.getRideTime()).thenReturn(LocalTime.parse("15:28:35"));
		when(tripMock.getVehicleId()).thenReturn("MP07GA6442");
		
		
		
		List<TripResponseDTO> list=tripServiceImpl.getTripResponseModels();
		assertTrue(list.size()==1);
		}catch(Exception e) {
			assertTrue(false);
		}
	}

	@Test
	public void getTripsResponseModels_positiveWhenMoreThanOneModelIsFound() {
		try {
		Iterable<Trip> iterableMock=Mockito.mock(Iterable.class);
		when(tripRepos.findAll()).thenReturn(iterableMock);
		Iterator<Trip> iteratorMock=Mockito.mock(Iterator.class);
		when(iterableMock.iterator()).thenReturn(iteratorMock);
		when(iteratorMock.hasNext()).thenReturn(true).thenReturn(true).thenReturn(false);
		Trip tripMock=Mockito.mock(Trip.class);
		when(iteratorMock.next()).thenReturn(tripMock);
		when(tripMock.getTripId()).thenReturn("0900PUGW");
		when(tripMock.getCreatorUserId()).thenReturn(3L);
		when(tripMock.getFromLoc()).thenReturn("Pune");
		when(tripMock.getToLoc()).thenReturn("Gwalior");
		when(tripMock.getNoOfSeat()).thenReturn(45);
		when(tripMock.getSeatsFilled()).thenReturn(4);
		when(tripMock.getRideDate()).thenReturn(LocalDate.of(2024,Month.FEBRUARY,27));
		when(tripMock.getRideStatus()).thenReturn(RideStatus.Planned);
		when(tripMock.getRideTime()).thenReturn(LocalTime.parse("15:28:35"));
		when(tripMock.getVehicleId()).thenReturn("MP07GA6442");
		
		
		List<TripResponseDTO> list=tripServiceImpl.getTripResponseModels();
		assertTrue(list.size()>1);
		}catch(Exception e) {
			assertTrue(false);
		}
	}
}